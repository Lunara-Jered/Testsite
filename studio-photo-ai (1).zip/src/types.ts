export interface CitizenUser {
  id: number;
  uid: string;
  email: string;
  role: "admin" | "agent" | "citoyen";
  firstName?: string | null;
  lastName?: string | null;
  phoneNumber?: string | null;
  dateOfBirth?: string | null;
  placeOfBirth?: string | null;
  nationalIdNumber?: string | null;
  address?: string | null;
  district?: string | null;
  isVerified?: boolean;
  createdAt?: string;
}

export interface MairieService {
  id: number;
  slug: string;
  name: string;
  description: string;
  categorySlug: "etat-civil" | "urbanisme";
  icon: string; // Lucide icon
  estimatedTime: string;
  requiredDocuments: string;
  feeAmount: string;
}

export interface NewsArticle {
  id: number;
  title: string;
  slug: string;
  summary: string;
  content: string;
  featuredImage?: string | null;
  isPublished: boolean;
  isFeatured: boolean;
  publicationDate: string;
  viewCount: number;
}

export interface MairieEvent {
  id: number;
  title: string;
  description: string;
  startDate: string;
  endDate: string;
  location: string;
  isActive: boolean;
}

export interface UnifiedDossier {
  id: number;
  type: "birth" | "marriage" | "id" | "permit" | "work";
  typeLabel: string; // "Naissance", "Mariage", etc.
  citizenEmail?: string;
  userId?: number;
  ref: string;
  status: "SUBMITTED" | "PROCESSING" | "APPROVED" | "REJECTED" | "COMPLETED" | "CELEBRATED" | "READY" | "COLLECTED" | "UNDER_REVIEW" | "DELIVERED" | "AUTHORIZED" | "REFUSED";
  details: string; // Custom summary text
  date?: string;
  comments?: string | null;
}

export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  isRead: boolean;
  notificationType: "INFO" | "STATUS_UPDATE" | "DOCUMENT";
  link?: string | null;
  createdAt: string;
}

export interface ContactMessage {
  id: number;
  userId?: number | null;
  subject: "GENERAL" | "CIVIL_REGISTRY" | "URBANISM" | "COMPLAINT" | "SUGGESTION";
  fullName: string;
  email: string;
  phone?: string | null;
  message: string;
  isProcessed: boolean;
  response?: string | null;
  createdAt: string;
}
